import boto

# Blank EC2 recipe example
